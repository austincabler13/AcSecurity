# run_scanner.py

from src.scanner import main

if __name__ == "__main__":
    main()

## Copyright (C) 2024  Austin Cabler
