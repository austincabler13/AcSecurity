from src.scanner import AcSecurity

scanner = AcSecurity('C:/Users/Cable/Documents/GitHub/CGS/AcSecurity/tests')
vulnerabilities = scanner.scan()
